#ifndef MILLCONTROL_DATAEDITORDATA_H
#define MILLCONTROL_DATAEDITORDATA_H

class DataEditorData {
public:
    virtual void drawEditor();

    virtual int *getData();
};

#endif //MILLCONTROL_DATAEDITORDATA_H
