#ifndef MILLCONTROL_TIMED_H
#define MILLCONTROL_TIMED_H

class Timed {
public:
    virtual void run();
};

#endif //MILLCONTROL_TIMED_H